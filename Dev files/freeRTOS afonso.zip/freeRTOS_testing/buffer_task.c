//*****************************************************************************
//
// switch_task.c - A simple switch task to process the buttons.
//
// Copyright (c) 2012-2017 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
//
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
//
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
//
// This is part of revision 2.1.4.178 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/rom.h"
#include "drivers/buttons.h"
#include "utils/uartstdio.h"

#include "switch_task.h"
#include "led_task.h"

#include "priorities.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"


#include "LCD/LCD.h"
#include "structs.h"
#include "aux_functions.h"

#include <string.h>

//*****************************************************************************
//
// The stack size for the display task.
//
//*****************************************************************************
#define BUFFERTASKSTACKSIZE        1024        // Stack size in words




#define LCD_Delay 150

#define BUFFER_SIZE 6

//*****************************************************************************
//
// This task reads the buttons' state and passes this information to LEDTask.
//
//*****************************************************************************



static void
Buff_Task(void *pvParameters)
{
    int buffer_line=0;
    int cont_total=0;
    char  UART_msg[50];
    //char aux[50];

    char buffer[20][70];
    lcd_packet packet_out;
    buffer_packet packet_in;
    packet_in.packet_position=0;


    //Lcd_Clear();

    while(1)
    {
        if(xQueueReceive (UART_Buffer_Queue, &UART_msg, 5/ portTICK_RATE_MS)==pdPASS)
        {
            //while(1); // waiting vazio
            //Lcd_Clear();
            //vTaskDelay(50 / portTICK_RATE_MS);
            //Lcd_Write_String(UART_msg);


            //vTaskDelay(1000 / portTICK_RATE_MS);
            //while(1);
            cont_total++;

            // semaphoro para aceder?

            strcpy(buffer[buffer_line], UART_msg);


            vTaskDelay(50 / portTICK_RATE_MS);

            //Lcd_Write_String(buffer[buffer_line]);

            buffer_line++;

            if(buffer_line==20 ) buffer_line=0;


        }




        // queue pedido menu
        if(xQueueReceive (Menu_Buffer_Queue, &packet_in, 10/ portTICK_RATE_MS) == pdPASS)
        {

            if(packet_in.command == 1)  // Display whole packet
            {

                //int aux_what = packet_in.packet_position;
                //Lcd_Write_Integer(aux_what);
                //vTaskDelay(50 / portTICK_RATE_MS);
                strcpy(packet_out.msg, buffer[packet_in.packet_position]);
                packet_out.identifier=MENU_PACKET_FULL;
                //Lcd_Set_Cursor(1,1);
                //vTaskDelay(50 / portTICK_RATE_MS);
                //Lcd_Write_String(packet_out.msg);
                //vTaskDelay(50 / portTICK_RATE_MS);

                xQueueSendToBack(Lcd_Write_Queue, &packet_out, portMAX_DELAY);
            }
            if(packet_in.command == 2) // Display RSSI
            {
                // smth smth implementation of string divition thing
            }
            if(packet_in.command== 3) // number of packets
            {
                packet_out.identifier = MENU_PACKET_COUNT;
                packet_out.cont = cont_total;
                xQueueSendToBack(Lcd_Write_Queue, &packet_out, portMAX_DELAY);
            }
            if (packet_in.command == 4) // RTC Time setup
            {
                //setup timer RTC thing missing here!!
            }

        }






        /*
        //Lcd_Clear();
        //vTaskDelay(pdMS_TO_TICKS(10));
        //Lcd_Write_String(UART_msg);
        //while(1);
        if(buffer.head<5)
        {
            circ_buff_push(&buffer, UART_msg);

            //Lcd_Clear();
            //vTaskDelay(pdMS_TO_TICKS(10));
            //Lcd_Write_String(buffer.buffer[buffer.tail]);
            //while(1);
            //Lcd_Clear();
            //vTaskDelay(pdMS_TO_TICKS(10));

//            Lcd_Write_String(UART_msg);

 //           while(1);
            //cont1++;
        }
        else
        {

            //circ_buff_pop(&buffer, aux);
            circ_buff_push(&buffer, UART_msg);

            packet_out.identifier=MENU_KEY;
            strcpy(packet_out.msg, buffer.buffer[buffer.head]);
            //vTaskDelay(1000 / portTICK_RATE_MS);


            xQueueSendToBack(Lcd_Write_Queue, &packet_out, 50/ portTICK_RATE_MS);
            vTaskDelay(1000 / portTICK_RATE_MS);


            strcpy(packet_out.msg, buffer.buffer[cont]);
            xQueueSendToBack(Lcd_Write_Queue, &packet_out, 50/ portTICK_RATE_MS);



        }
        */


        /*
        if(data_in.identifier == MENU_TMP)  // TEMPERATURE DISPLAY tinha um ; aqui
        {

            ftoa(data_in.data, temperature, 2);

            Lcd_Clear();
            vTaskDelay(50 / portTICK_RATE_MS);
            Lcd_Write_String(temperature);
            //Lcd_Write_Char(0xDF);
            //Lcd_Write_Char('C');


        } // resto dos menus
        */
         /*
        else if(data_in.identifier == MENU_KEY)
        {
            Lcd_Clear();
            vTaskDelay (50/portTICK_RATE_MS);
            Lcd_Write_String(data_in.msg);
        }
        */

        vTaskDelay( LCD_Delay/ portTICK_RATE_MS);
    }

}

//*****************************************************************************
//
// Initializes the switch task.
//
//*****************************************************************************
uint32_t
Buff_TaskInit(void)
{




    if(xTaskCreate(Buff_Task, (const portCHAR *)"BUFFER", BUFFERTASKSTACKSIZE, NULL, tskIDLE_PRIORITY + PRIORITY_BUFFER_TASK, NULL) != pdTRUE)
    {
        //smth bad
        return 1;
    }





    //vTaskDelay( LCD_Delay/ portTICK_RATE_MS);

    return 0;
}
