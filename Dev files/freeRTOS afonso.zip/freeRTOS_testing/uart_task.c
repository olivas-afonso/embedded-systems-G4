/*
 * uart_task.c
 *
 *  Created on: 22/12/2023
 *      Author: carlo
 */

#include "uart_task.h"

#include "LCD/LCD.h"

#include "structs.h"



int32_t counter_uart=0;
void UART_Init(void)
{

    //
    // Enable the peripherals used by this example.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

    //
    // Set GPIO B0 and B1 as UART pins.
    //
    GPIOPinConfigure(GPIO_PB0_U1RX);
    GPIOPinConfigure(GPIO_PB1_U1TX);

    GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Configure the UART for 9600, 8-N-1 operation.
    //
    UARTConfigSetExpClk(UART1_BASE, SysCtlClockGet(), 9600,
                            (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                             UART_CONFIG_PAR_NONE));

}

int32_t UART_receive(void){

    int32_t uart_received;
    uart_received=UARTCharGetNonBlocking(UART1_BASE);
    return uart_received;


}

static void
UartTaskReceive(void *pvParameters)
{
    uint8_t i = 0;
    char receivedChar;
    char full_msg[buffer_size];
    int char_init = 0;
    int32_t uart_counter=0;

        while (1)
        {
            while (i < buffer_size - 1)
            {
                //Aguarda ate que um caracter esteja disponivel para leitura
                while (!UARTCharsAvail(UART1_BASE))
                    vTaskDelay(pdMS_TO_TICKS(1));

                // Le um caractere da porta UART
                receivedChar = UARTCharGet(UART1_BASE);

                // Verifica se e um caracter de termina�ao
                if (receivedChar == 'P')
                {
                    char_init = 1;
                }

                // Verifica se e um caracter de termina�ao
                if (receivedChar == '\n' || receivedChar == '\r')
                {
                    char_init = 0;
                    // Adiciona o caracter nulo ao final da string
                    full_msg[i] = '\0';

                    xQueueSendToBack(UART_Buffer_Queue, &full_msg, portMAX_DELAY);

                    //xQueueReceive(uart_queue_counter, &uart_counter, 100);
                    //Lcd_Clear();
                    //vTaskDelay(pdMS_TO_TICKS(10));
                    //Lcd_Write_String(full_msg);
                    //while(1);
                    //uart_counter=uart_counter+1;
                    //xQueueOverwrite(uart_queue_counter, &uart_counter);

                    i = 0;
                    break;
                }

                // Armazena o caracter
                if (char_init == 1)
                {
                    full_msg[i++] = receivedChar;
                    //Lcd_Write_Char(receivedChar);
                    //i++;
                    //return buffer;
                }
            }


            vTaskDelay(pdMS_TO_TICKS(10));
        }
}

uint32_t
UartTaskReceiveInit(void)
{

    // UART
    UART_Init();

    //
    // Create the Uart task.
    //
    if(xTaskCreate(UartTaskReceive, (const portCHAR *)"Uart receive", UARTSTACKSIZE, NULL,
                   tskIDLE_PRIORITY + PRIORITY_UART_TASK, NULL) != pdTRUE)
    {
        return(1);
    }

    //
    // Success.
    //
    return(0);
}
