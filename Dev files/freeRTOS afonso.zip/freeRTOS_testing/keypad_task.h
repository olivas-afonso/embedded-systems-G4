/*
 * keypad_task.h
 *
 *  Created on: 03/01/2024
 *      Author: olivas
 */

#ifndef KEYPAD_TASK_H_
#define KEYPAD_TASK_H_

extern uint32_t Keypad_TaskInit(void);

#endif /* KEYPAD_TASK_H_ */
