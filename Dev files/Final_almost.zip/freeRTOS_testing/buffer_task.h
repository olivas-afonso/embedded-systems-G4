/*
 * buffer_task.h
 *
 *  Created on: 04/01/2024
 *      Author: olivas
 */

#ifndef BUFFER_TASK_H_
#define BUFFER_TASK_H_

extern uint32_t Buff_TaskInit(void);

#endif /* BUFFER_TASK_H_ */
