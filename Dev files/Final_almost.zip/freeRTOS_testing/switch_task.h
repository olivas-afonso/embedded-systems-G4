

#ifndef __SWITCH_TASK_H__
#define __SWITCH_TASK_H__


extern uint32_t LCD_TaskInit(void);

#endif // __SWITCH_TASK_H__
