/*
 * keypad.h
 *
 *  Created on: 03/01/2024
 *      Author: olivas
 */

#ifndef KEYPAD_KEYPAD_H_
#define KEYPAD_KEYPAD_H_


char keyboard (void);
void IntGPIOd(void);
void Timer0IntHandler(void);
void keypad_init(void);



#endif /* KEYPAD_KEYPAD_H_ */
