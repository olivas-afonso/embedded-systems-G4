

#ifndef __LED_TASK_H__
#define __LED_TASK_H__


extern uint32_t TMP_TaskInit(void);

#endif // __LED_TASK_H__
